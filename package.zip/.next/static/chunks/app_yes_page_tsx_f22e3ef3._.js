(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_yes_page_tsx_f22e3ef3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_yes_page_tsx_f22e3ef3._.js",
  "chunks": [
    "static/chunks/_46626b40._.js"
  ],
  "source": "dynamic"
});
