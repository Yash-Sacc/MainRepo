module.exports = {

"[project]/app/yes/layout.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>YesLayout),
    "metadata": (()=>metadata)
});
const metadata = {
    title: "I Love You Too! ❤️",
    description: "Thank you for saying yes!"
};
function YesLayout({ children }) {
    return children;
}
}}),

};

//# sourceMappingURL=app_yes_layout_tsx_f4a4814c._.js.map